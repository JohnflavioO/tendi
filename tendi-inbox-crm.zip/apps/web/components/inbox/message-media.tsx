'use client';

import { useState } from 'react';
import { FileText, ImageOff } from 'lucide-react';
import { MEDIA_LABEL, mediaKind, safeMediaUrl } from '@/lib/inbox-utils';

type MediaMessage = { message_type: string; body: string | null; payload: Record<string, unknown> | null };

const textClass = 'whitespace-pre-wrap text-[13px] leading-6';

/**
 * Conteúdo de uma mensagem: mídia (imagem, vídeo, áudio, documento, figurinha) e/ou texto.
 * O link da mídia vem do webhook da D-API (payload.media_url) e só é usado se for http(s).
 */
export function MessageMedia({ message }: { message: MediaMessage }) {
  const [failed, setFailed] = useState(false);
  const kind = mediaKind(message.message_type);
  const payload = message.payload ?? {};
  const url = kind ? safeMediaUrl(payload.media_url) : null;
  const filename = typeof payload.filename === 'string' && payload.filename.trim() ? payload.filename.trim() : null;
  const caption = message.body && message.body.trim() ? message.body : null;

  let media: React.ReactNode = null;
  if (kind) {
    if (!url || failed) {
      media = <p className="mb-1 flex items-center gap-2 rounded-lg bg-black/5 px-3 py-2 text-xs opacity-80"><ImageOff size={14} />{MEDIA_LABEL[kind]} indisponível</p>;
    } else if (kind === 'image' || kind === 'sticker') {
      media = <a href={url} target="_blank" rel="noreferrer noopener" className="mb-1 block"><img src={url} alt={caption ?? MEDIA_LABEL[kind]} loading="lazy" onError={() => setFailed(true)} className={kind === 'sticker' ? 'max-h-40 w-auto' : 'max-h-72 w-auto max-w-full rounded-xl object-cover'} /></a>;
    } else if (kind === 'video') {
      media = <video controls preload="metadata" src={url} onError={() => setFailed(true)} className="mb-1 max-h-72 w-full max-w-sm rounded-xl" />;
    } else if (kind === 'audio') {
      media = <audio controls preload="none" src={url} onError={() => setFailed(true)} className="mb-1 h-10 w-64 max-w-full" />;
    } else {
      media = <a href={url} target="_blank" rel="noreferrer noopener" className="mb-1 flex items-center gap-3 rounded-xl bg-black/5 px-3 py-2.5 text-xs font-semibold hover:bg-black/10"><FileText size={18} className="shrink-0" /><span className="min-w-0 truncate">{filename ?? 'Documento'}</span><span className="ml-auto shrink-0 text-[10px] font-medium opacity-70">Abrir</span></a>;
    }
  }

  const text = caption ?? (kind ? null : `[${message.message_type}]`);
  return <>{media}{text && <p className={textClass}>{text}</p>}</>;
}
